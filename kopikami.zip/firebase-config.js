// GANTI nilai di bawah ini dengan config dari project Firebase kamu sendiri.
// Cara ambil: console.firebase.google.com -> buat project -> Project settings -> scroll ke "Your apps" -> tambah Web App -> copy config di sini.
// Lalu di Firestore Database, buat database (mode "test" dulu biar gampang, aman untuk tugas sekolah skala kecil).

const firebaseConfig = {
  apiKey: "ISI_API_KEY",
  authDomain: "ISI_PROJECT.firebaseapp.com",
  projectId: "ISI_PROJECT_ID",
  storageBucket: "ISI_PROJECT.appspot.com",
  messagingSenderId: "ISI_SENDER_ID",
  appId: "ISI_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
