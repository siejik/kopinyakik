# Website Pesan Minum

Website sederhana untuk jualan minuman ke guru. Tidak pakai framework/build tool — murni HTML + Tailwind (CDN) + Firebase (CDN), supaya gampang langsung di-deploy ke Vercel tanpa proses build.

## Isi Folder
- `index.html` — halaman konsumen (guru): lihat produk, pesan.
- `admin.html` — halaman admin (kamu): kelola produk & pesanan.
- `firebase-config.js` — tempat isi kredensial Firebase kamu.

## Langkah Setup

### 1. Buat Project Firebase (gratis)
1. Buka [console.firebase.google.com](https://console.firebase.google.com), buat project baru.
2. Di dalam project, klik ikon `</>` (Web App) untuk daftarkan web app, kasih nama bebas.
3. Firebase akan kasih kode `firebaseConfig` — copy nilainya ke file `firebase-config.js` (ganti semua yang tulisannya `ISI_...`).
4. Di menu kiri, buka **Firestore Database** → **Create database** → pilih **Start in test mode** (cukup untuk tugas sekolah skala kecil, tidak perlu rules rumit).

### 2. Coba Lokal
Buka `index.html` langsung di browser (double click), atau pakai extension "Live Server" kalau pakai VS Code. Buka juga `admin.html` di tab lain untuk coba alur admin.

### 3. Deploy ke Vercel
1. Push folder ini ke repo GitHub.
2. Buka [vercel.com](https://vercel.com) → New Project → import repo tadi.
3. Karena ini static HTML (bukan framework), pas Vercel tanya "Framework Preset" pilih **Other** — tidak perlu build command, langsung deploy.
4. Setelah deploy selesai, kamu akan dapat link seperti `nama-project.vercel.app`. Bagikan link itu ke guru-guru.

### 4. Cara Pakai Sehari-hari
- Buka `link-kamu.vercel.app/admin.html`, isi form produk (nama, harga, keterangan). Foto boleh dikosongkan dulu, nanti isi URL foto (upload ke Google Drive/Imgur dulu, ambil link gambarnya).
- Bagikan `link-kamu.vercel.app` (tanpa `/admin.html`) ke guru untuk pesan.
- Pantau tab "Pesanan" di halaman admin — otomatis update saat ada pesanan masuk. Klik "Terima Pesanan" saat mulai diproses, klik "Selesai" saat sudah diantar.

## Catatan
- Tidak ada sistem login admin (sesuai keputusan awal) — halaman admin diakses lewat menu titik tiga (⋮) di pojok kanan atas halaman utama, atau langsung buka `/admin.html`. Kalau nanti mau ditambah proteksi sederhana (PIN), tinggal minta dilanjutkan.
- Produk memang didesain untuk satu jenis saja — form admin akan meng-update produk yang sama, bukan menambah produk baru berulang.
